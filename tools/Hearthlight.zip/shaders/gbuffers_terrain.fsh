#version 430 compatibility
/* RENDERTARGETS: 0,1,2 */
#define PASS_VOXEL

#include "/lib/gbuffer_fs.glsl"
