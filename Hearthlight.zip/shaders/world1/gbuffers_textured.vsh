#version 400 compatibility
#define WORLD_END
#define PROGRAM_GBUFFERS_TEXTURED
#include "/program/gbuffers_textured.vsh"
